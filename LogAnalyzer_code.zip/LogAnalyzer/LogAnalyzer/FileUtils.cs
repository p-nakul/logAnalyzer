﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogAnalyzer
{
    internal class FileUtils
    {
        public static string[] get_log_files(string folderPath)
        {
            try
            {
                string[] logFiles = Directory.GetFiles(folderPath, "*.log", SearchOption.AllDirectories);
                return logFiles;
            }
            catch (Exception ex) { 
                return new string[0];
            }
        }

        public static string read_log_file(string filePath)
        {
            try
            {
                StreamReader sr = new StreamReader(filePath);
                string data = sr.ReadToEnd();
                sr.Close();
                return data;
            }
            catch (Exception ex) {
                return "";
            }
        }
    }
}
