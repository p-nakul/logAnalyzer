﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using static System.Net.Mime.MediaTypeNames;
using System.Windows.Shapes;

namespace LogAnalyzer
{
    internal class LogUtils
    {
        public static void find_pass_fail_string(string data, LogFile logFile)
        {
            try
            {
                string linePattern = @"PASSED:\s*\d+,\s*FAILED:\s*\d+,\s*SKIPPED:\s*\d+";
                // Pattern to extract numbers
                string numberPattern = @"PASSED:\s*(\d+),\s*FAILED:\s*(\d+),\s*SKIPPED:\s*(\d+)";

                string[] lines = data.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

                int count = 0;
                foreach (string line in lines)
                {
                    if (Regex.IsMatch(line, linePattern))
                    {
                        logFile.passFailString = line.Trim();
                        logFile.passFailStringLineNumber = count;
                        
                        Match match = Regex.Match(line, numberPattern);
                        if (match.Success)
                        {
                            int passed = int.Parse(match.Groups[1].Value);
                            int failed = int.Parse(match.Groups[2].Value);
                            int skipped = int.Parse(match.Groups[3].Value);
                            if(failed == 0 && skipped == 0)
                            {
                                logFile.isPassed = true;
                            }
                        }
                        return;
                    }

                    count++;
                }


                // string not found
                logFile.passFailString = "";
                logFile.passFailStringLineNumber = 0;
                logFile.isPassed = false;
                return;
            }
            catch (Exception e) {
                logFile.passFailString = "";
                logFile.passFailStringLineNumber = 0;
                logFile.isPassed = false;
            }
        }
    }
}
