﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Forms;

namespace LogAnalyzer
{
    /// <summary>
    /// Interaction logic for LogResults.xaml
    /// </summary>
    public partial class LogResults : Window
    {
        
        public List<LogFile> mLogFiles = new List<LogFile>();
        public LogResults(List<LogFile> lr)
        {
            InitializeComponent();
            mLogFiles = lr;

            

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dataGrid1.ItemsSource = mLogFiles;
        }

        private void OpenFileButton_Click(object sender, RoutedEventArgs e)
        {
            // Get the selected LogFile object for this row
            var button = sender as System.Windows.Controls.Button;
            var logFile = button?.DataContext as LogFile;

            if (logFile != null)
            {
                OpenFile(logFile.logFilePath);
            }
        }

        // Method to open the file
        private void OpenFile(string filePath)
        {
            try
            {
                // Try to open the file with the default associated application
                Process.Start(new ProcessStartInfo
                {
                    FileName = filePath,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show($"Could not open file: {filePath}\nError: {ex.Message}", "Error");
            }
        }
    }
}
