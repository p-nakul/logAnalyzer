﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogAnalyzer
{
    public class LogFile
    {
        public string logFilePath { get; set; }
        public string logFileName { get; set; }

        public string passFailString { get; set; }

        public int passFailStringLineNumber { get; set; }   

        public bool isPassed { get; set; }
        public LogFile() { 
        }
    }
}
