﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.ComponentModel;

namespace LogAnalyzer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private BackgroundWorker worker;
        private string mFolderPath = "";
        private int totalLogFiles = 0;
        public List<LogFile> mLogFiles = new List<LogFile>();

        public MainWindow()
        {
            InitializeComponent();
            progressBar.Value = 0;
            worker = new BackgroundWorker();
            worker.DoWork += Worker_DoWork;
            worker.ProgressChanged += Worker_ProgressChanged;
            worker.RunWorkerCompleted += Worker_RunWorkerCompleted;
            worker.WorkerReportsProgress = true;
            worker.WorkerSupportsCancellation = true;
        }

        private void Worker_RunWorkerCompleted(object? sender, RunWorkerCompletedEventArgs e)
        {
            resultBtn.IsEnabled = true;
            progressBar.Value = 100;
        }

        private void Worker_ProgressChanged(object? sender, ProgressChangedEventArgs e)
        {
            if(e.ProgressPercentage == 1)
            {
                status.Text = $"total files found {totalLogFiles}";
                progressBar.Value = 10;
            }

            if (e.ProgressPercentage == 2)
            {
                status.Text = $"file processed {mLogFiles.Count}";
                if(progressBar.Value < 100)
                {
                    progressBar.Value = progressBar.Value + 1;
                }
            }

        }

        private void Worker_DoWork(object? sender, DoWorkEventArgs e)
        {
            // get all log files
            string[] logFiles = FileUtils.get_log_files(mFolderPath);

            int totalFiles = logFiles.Length;

            worker.ReportProgress(1);

            if (totalFiles == 0) {
                return;
            }

            foreach (string file in logFiles) {
                LogFile l = new LogFile();
                l.logFileName = System.IO.Path.GetFileName(file);
                l.logFilePath = file;
                mLogFiles.Add(l);
                string data = FileUtils.read_log_file(file);
                LogUtils.find_pass_fail_string(data, l);
                worker.ReportProgress(2);
            }




            //throw new NotImplementedException();
        }

        private void browseBtn_Click(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            DialogResult dialogResult = dialog.ShowDialog();
            resultBtn.IsEnabled = false;
            if(dialogResult == System.Windows.Forms.DialogResult.OK)
            {
                mLogFiles.Clear();
                string folderPath = dialog.SelectedPath;
                status.Text = $"Selected folder {folderPath}";
                mFolderPath = folderPath;
                if (!worker.IsBusy)
                {
                    worker.RunWorkerAsync();
                    progressBar.Value = 0;
                }
            }
        }

        private void resultBtn_Click(object sender, RoutedEventArgs e)
        {
            LogResults lr = new LogResults(mLogFiles);
            lr.Show();
        }
    }
}